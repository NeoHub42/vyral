# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.x.x   | :white_check_mark: |

## Contact information

Open an issue, contact me@paillat.dev or use github's vulnerability reporting feature.
